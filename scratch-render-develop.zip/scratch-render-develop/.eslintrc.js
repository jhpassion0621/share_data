module.exports = {
    root: true,
    extends: ['scratch', 'scratch/node', 'scratch/es6']
};
