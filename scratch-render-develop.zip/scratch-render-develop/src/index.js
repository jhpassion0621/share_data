const RenderWebGL = require('./RenderWebGL');

/**
 * Export for NPM & Node.js
 * @type {RenderWebGL}
 */
module.exports = RenderWebGL;
