module.exports = {
    extends: ['scratch'],
    env: {
        browser: true
    },
    rules: {
        'no-console': 'off'
    }
};
