module.exports = {
    extends: 'scratch-semantic-release-config',
    branches: [
        {
            name: 'develop'
            // default channel
        }
        // TODO: add hotfix config after at least one normal release
    ]
};
